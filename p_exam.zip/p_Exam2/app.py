from flask import Flask, render_template, redirect, request, flash, session
from flask_bcrypt import Bcrypt
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from sqlalchemy.sql import func
from datetime import datetime, timedelta
import re

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///p_exam2.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = "secrets"
db=SQLAlchemy(app)
migrate=Migrate(app, db)
bcrypt=Bcrypt(app)

likes_table=db.Table('likes',
    db.Column("thoughts_id", db.Integer, db.ForeignKey("thoughts.id"), primary_key=True),
    db.Column("user_id", db.Integer, db.ForeignKey("users.id"), primary_key=True),
    db.Column('created_at', db.DateTime, server_default=func.now())
)

followers_table=db.Table('followers',
    db.Column("follower_id", db.Integer, db.ForeignKey("users.id"), primary_key=True),
    db.Column("followed_id", db.Integer, db.ForeignKey("users.id"), primary_key=True),
    db.Column("created_at", db.DateTime, server_default=func.now())
)

class User(db.Model):
    __tablename__ = "users"
    id=db.Column(db.Integer, primary_key=True)
    first_name=db.Column(db.String(100))
    last_name=db.Column(db.String(100))
    email=db.Column(db.String(200))
    password_hash=db.Column(db.String(100))
    liked_thoughts=db.relationship("thoughts", secondary=likes_table)
    followers=db.relationship("User", 
        secondary=followers_table, 
        primaryjoin=id==followers_table.c.followed_id, 
        secondaryjoin=id==followers_table.c.follower_id,
        backref="following")
    created_at=db.Column(db.DateTime, server_default=func.now())
    updated_at=db.Column(db.DateTime, server_default=func.now(),onupdate=func.now())

    def full_name(self):
        return "{} {}".format(self.first_name, self.last_name)
    
    def like_thought(self, thought):
        if not self.has_liked_thought(thought):
            like = likes_table(user_id=self.id, thought_id=thought.id)
            db.session.add(like)

    def unlike_thought(self, thought):
        if self.has_liked_thought(thought):
            likes_table.query.filter_by(
                user_id=self.id,
                thought_id=thought.id).delete()

    def has_liked_thought(self, thought):
        return likes_table.query.filter(
            likes_table.user_id == self.id,
            likes.thought_id == thought.id).count() > 0
    @classmethod
    def add_new_user(cls,data):
        new_user = cls(
            first_name=data['first_name'],
            last_name=data['last_name'],
            email=data['email'],
            password_hash=bcrypt.generate_password_hash(data['password'])
        )
        db.session.add(new_user)
        db.session.commit()
        return new_user

    @classmethod
    def find_registration_errors(cls, form_data):
        errors=[]
        if len(form_data['first_name'])<3:
            errors.append("first name is not long enough")
        if len(form_data['last_name'])<3:
            errors.append("last name is not long enough")
        if not EMAIL_REGEX.match(form_data['email']):
            errors.append("invalid email")
        if form_data['password'] != request.form['confirm']:
            errors.append("password dont match")
        if len(form_data['password']) < 8:
            errors.append("password isn't long enough")
        return errors

    @classmethod
    def register_new_user(cls, form_data):
        errors = cls.find_registration_errors(form_data)
        valid = len(errors)==0
        data = cls.add_new_user(form_data) if valid else errors
        return {
            "status": "good" if valid else "bad",
            "data": data
        }


class thoughts(db.Model):
    __tablename__="thoughts"
    id=db.Column(db.Integer, primary_key=True)
    message=db.Column(db.String(140))
    author_id=db.Column(db.Integer,db.ForeignKey("users.id"))
    author=db.relationship("User", backref="thoughts", cascade="all")
    likers=db.relationship("User", secondary=likes_table)
    created_at=db.Column(db.DateTime, server_default=func.now())
    updated_at=db.Column(db.DateTime, server_default=func.now(),onupdate=func.now())

    @classmethod
    def add_new_thoughts(cls,thoughts):
        db.session.add(thoughts)
        db.session.commit()
        return thoughts
    
    def age(self):
        return self.created_at
        return age

class Follow(db.Model):
    __tablename__="follows"
    id=db.Column(db.Integer, primary_key=True)
    user_id=db.Column(db.Integer, db.ForeignKey("users.id"))
    user=db.relationship("User",backref="likes", cascade="all")
    user_id=db.Column(db.Integer, db.ForeignKey("users.id"))
    user=db.relationship("User",backref="likes", cascade="all")
    created_at=db.Column(db.DateTime, server_default=func.now())

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route("/")
def main():
    return render_template("main.html")

@app.route("/register", methods=["POST"])
def register():
    result=User.register_new_user(request.form)
    if result['status']=="good":
        user=result['data']
        session['cur_user'] = {
            "first": user.first_name,
            "last": user.last_name,
            "id": user.id
        }
        return redirect("/thoughts")
    else:
        errors=result['data']
        for error in errors:
            flash(error)
        return redirect("/")

@app.route("/thoughts")
def dashboard():
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    cur_user=User.query.get(session['cur_user']['id'])
    approved_users_ids = [user.id for user in cur_user.following]+[cur_user.id]
    all_thoughts=thoughts.query.filter(thoughts.author_id.in_(approved_users_ids)).all()
    return render_template("thoughts.html", thoughts=all_thoughts)

    return render_template("thoughts.html", thoughts=all_thoughts) if "cur_user" in session else not_logged_in()

@app.route("/thoughts/<int:t_id>")
def dashboard_detail(t_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    cur_user=User.query.get(session['cur_user']['id'])
    approved_users_ids = [user.id for user in cur_user.following]+[cur_user.id]
    thought_id = thoughts.query.get(t_id).id
    all_thoughts=thoughts.query.filter(thoughts.author_id.in_(approved_users_ids)).all()
    return render_template("thoughts_detail.html", thoughts=all_thoughts, thought_id=thought_id)

@app.route("/login", methods=['thought'])
def login():
    user=User.query.filter_by(email=request.form['email']).all()
    valid = True if len(user)==1 and bcrypt.check_password_hash(user[0].password_hash, request.form['password']) else False
    if valid:
        session['cur_user'] = {
            "first": user[0].first_name,
            "last": user[0].last_name,
            "id": user[0].id
        }
        return redirect("/thoughts")
    else:
        flash("Invalid login credentials")
        return redirect("/")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/thoughts", methods=["POST"])
def add_thoughts():
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    new_thoughts=thoughts(
        message=request.form['thoughts'],
        author_id=int(session['cur_user']['id'])
    )
    if len(new_thoughts.message) > 0:
        thoughts.add_new_thoughts(new_thoughts)
    else:
        flash("need more thoughts length!")
    return redirect("/thoughts")

@app.route("/thoughts/<thoughts_id>/delete", methods=['thought'])
def delete_thoughts(thoughts_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    thoughts_being_deleted=thoughts.query.get(thoughts_id)
    thoughts_author=thoughts_being_deleted.author
    thoughts_author.thoughts.remove(thoughts_being_deleted)
    db.session.commit()
    return redirect("/thoughts")

@app.route("/thoughts/<thoughts_id>/like", methods=["POST"])
def add_like(thoughts_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    liked_thoughts=thoughts.query.get(thoughts_id)
    unliked_thoughts=thoughts.query.get(thoughts_id)
    liker=User.query.get(session['cur_user']['id'])
    liker.liked_thoughts.append(liked_thoughts)
    db.session.commit()
    return redirect("/thoughts")

@app.route("/thoughts/<thoughts_id>/unlike", methods=["POST"])
def remove_like(thoughts_id):
    # query = "DELETE FROM likes WHERE users_id = %(user_id)s AND thoughts_id = %(tweet_id)s"
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    thoughts_being_unliked=thoughts.query.get(thoughts_id)
    liker=User.query.get(session['cur_user']['id'])
    # liker.liked_thoughts.append(liked_thoughts)
    db.session.commit()
    return redirect("/thoughts")

@app.route("/thoughts/<thoughts_id>/edit")
def show_edit(thoughts_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    thought=thoughts.query.get(thoughts_id)
    return render_template("edit.html", thoughts=thought)

@app.route("/thoughts/<thoughts_id>/update", methods=["POST"])
def update_thoughts(thoughts_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    thought=thoughts.query.get(thoughts_id)
    if len(request.form['thoughts'])>0:
        thought.message=request.form['thoughts']
        db.session.commit()
        return redirect("/thoughts")
    else:
        flash("need more thoughts!")
        return render_template("edit.html", thoughts=thought)

@app.route("/users")
def show_users():
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    users_list=User.query.all()
    return render_template("users.html", users=users_list)

@app.route("/follow/<user_id>")
def follow_user(user_id):
    if "cur_user" not in session:
        flash("Please Log In")
        return redirect("/")
    logged_in_user=User.query.get(session['cur_user']['id'])
    followed_user=User.query.get(user_id)
    followed_user.followers.append(logged_in_user)
    db.session.commit()
    return redirect("/users")

if __name__ == "__main__":
    app.run(debug=True)